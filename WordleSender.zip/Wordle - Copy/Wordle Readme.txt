Project: Wordle

On my honor, I have neither given nor received any aid on this assignment.
Ellie Stuckey

In this project, I attempted to use the processing video class to make an animated background for the inside of the map, but could not get it to work.
When the program first starts, it waits for the mouse to move to have the text fade onto the screen. In order to go to the next screen, the user must click the 
screen to make the background white and the value of the counter for the number must be above 200 for the code to work properly. It then pulls up the 
wordle of the sorting hat after reading the file that is in the folder. This file contains 54 words relating to the Harry Potter series. Originally, this 
code would bring in the entire first book, sort it, and give the user back the most frequent words. However, since this requires multiple filters, 
I scrapped it for time's sake and made a text file of useful words. The program uses the readTxt function to read in the file and take in words of a certain 
length or over (all words met the length in the text file so that did not cause an issue). It then stores the data into an array reading each line as 
an element in the array. 

In the beginning, all of the PFonts are created and stored into variables. All PFonts are of type TTF and resemble the fonts actually used in the Harry
Potter series. These are implemented in the wordle. Variables to keep up with the count of the timing variables are also created and enstantiated. In 
order to have a smoother transition between frames, the frameRate was reduced to 10 frames per second. The draw function only gets implemented if the 
counters for the beginning and end are of the correct values. The words are put onto the screen by moving the origin and then rotating it where 
necessary. Fonts are changed for every word that gets implemented from the array. The words are arranged in the form of the sorting hat from the books.


References:
Processing API
Googled images of a hat